/**
 * Created by komal.chaudhary on 2/23/2016.
 */

// Factory For Hold Data between Controllers
// This Factory Hold Train Route API returned Information

angular.module("myApp").factory('Service_Intermediator', function () {
    return { Train_Route: [] };
});

