/**
 * Created by komal.chaudhary on 2/19/2016.
 */

/*
 *  Key_Train_API
 *  return : Railway API Key
 */
angular.module("myApp").factory('Key_Train_API', function () {


    return function getKey()
    {
        // komal pcedq5108
        // komal nkomalcg@gmail.com wokwg8584       <--
        // pravin sarpank@gmail.com wsjak4280
        // Narayan narayan943@gmail.com hnvbp5114
        // shashank shashankyadav1989@gmail.com vpeoo7497
        // Mohak mohakbarokar@gmail.com ocvhq2524
        // Pravin Mulchandani sammerrocker7@gmail ktgbb6932
        // rkchaudhary_2007@rediffmail.com xhwbb4814
        // sha2nkyaar@gmail.com kuoef4046



        var key = "wokwg8584";
        return key;
    }
});